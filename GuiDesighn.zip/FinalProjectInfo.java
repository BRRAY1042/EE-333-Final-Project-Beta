/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalprojectinfo;

/**
 *
 * @author Brett Ray
 */
public class FinalProjectInfo {
    
    //Requirments
    //handle Employees,Customers,Procucts,Orders
    
    //Order Managament System (OMS)
      //Employee can add remove and manage customers
      //Customer can order or checkout
    
    
    //-DIGiKey (PMS)
    //-Customer (CMS)
    //-Employees Managamnet System (Shared with DigiKey (EMS)
   
    
    // need password and Username to enter
    //diffrent interface depending on employee or customer
    //
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
