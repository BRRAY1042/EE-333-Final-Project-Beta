
package CMS;
public class CustomerInfo {
    private CMS.CustomerInfo.CustomerInfoStatus status;
    private String ID;
    private String firstName;
    private String lastName;
    private String address;
    private String email;
  
    public enum CustomerInfoStatus {
        active,
        inactive,
        unknown,
    }
//get and set
    
    public CMS.CustomerInfo.CustomerInfoStatus getStatus() {
        return(this.status);}  
    public String getID() {
        return (this.ID);}  
    public String getFirstName() {
        return (this.firstName);} 
    public String getLastName() {
        return (this.lastName);} 
    public String getAddress() {
        return (this.address);}
    public String getEmail() {
        return (this.email);}
    public boolean setFirstName(String firstName) {
        this.firstName = firstName;
        return(true);}
    public boolean setLastName(String lastName) {
        this.lastName = lastName;
        return(true);}
    public boolean setAddress(String address) {
        this.address = address;       
        return(true);}
    public boolean setEmail(String email) {
        this.email = email; 
        return(true);}
//to    
    public String toString() {
        return("");}
    public String toCustom() {
        String output = "";
        output += "ID: " + this.ID + '\n';
        output += "FirstName: " + this.firstName + '\n';
        output += "LastName: " + this.lastName + '\n';
        output += "Address: " + this.address + '\n';
        output += "Email: " + this.email + '\n';
        return(output);
    }
    public String toCSV() {
        String output = "";
        output += this.ID + ',';
        output += this.firstName + ',';
        output += this.lastName + ',';
        output += this.address + ',';
        output += this.email + '\n';      
        return(output);
    } 
    public String toXML() {
        String output = "";
        output += "<CustomerInfo>" + '\n';
        output += "   <ID>" + this.ID + "</ID>\n";
        output += "   <FirstName>" + this.firstName + "</FirstName>\n";
        output += "   <LastName>" + this.lastName + "</LastName>\n";
        output += "   <Address>" + this.address + "</Address>\n";
        output += "   <Email>" + this.email + "</Email>\n";
        output += "</CustomerInfo>" + '\n';
        return(output);
    }
    public String toJSON() {
        String output = "";
        output += "{\n";
        output += "   \"ID\":\"" + this.ID + "\",\n";
        output += "   \"FirstName\":\"" + this.firstName + "\",\n";
        output += "   \"LastName\":\"" + this.lastName + "\",\n";
        output += "   \"Address\":\"" + this.address + "\",\n";
        output += "   \"Email\":\"" + this.email + "\"\n";
        output += "}\n";  
        return(output);
    }    
    public static CMS.CustomerInfo fromCustom(String input) {
        CMS.CustomerInfo output = null;
        String ID = "";
        String firstName = "";
        String lastName = "";
        String address = "";
        String email = "";
        String[] lines;
        String[] chunks;
        int index;
        if(input == null) {
            System.out.println("fromCustom");
        } else if(input.length() == 0) {
            System.out.println("fromCustom");
        } else {lines = input.split("\n");
            if(lines.length == 5) {
                for(index = 0; index < 5; index++) {
                    // Splitting using Custom format, repeating through lines
                    chunks = lines[index].split(": ");
                    if(chunks[0].equalsIgnoreCase("ID") == true) {
                        ID = chunks[1];
                    } else if(chunks[0].equalsIgnoreCase("FirstName") == true) {
                        firstName = chunks[1];
                    } else if(chunks[0].equalsIgnoreCase("LastName") == true) {
                        lastName = chunks[1];
                    } else if(chunks[0].equalsIgnoreCase("Address") == true) {
                        address = chunks[1];
                    } else if(chunks[0].equalsIgnoreCase("Email") == true) {
                        email = chunks[1];}
                }
                try {
                    output = new CustomerInfo(ID, firstName, lastName, address, email);
                } catch (Exception ex) {
                    System.out.println("fromCustom" + ex.toString());}
            } else {
                System.out.println("fromCustom");}
        }
        return(output);
    }
    
    public static CMS.CustomerInfo fromCSV(String input) {
        CMS.CustomerInfo output = null;
        String ID = "";
        String firstName = "";
        String lastName = "";
        String address = "";
        String email = "";
        String[] chunks;
        if(input == null) {
            System.out.println("fromCSV");
        } else if(input.length() == 0) {
            System.out.println("fromCSV");
        } else {
            chunks = input.split(",");
            if(chunks.length == 5) {
                if(chunks[0].length() == 0) {
                    System.out.println("fromCSV");  
                } else {
                    ID = chunks[0];
                    firstName = chunks[1];
                    lastName = chunks[2];
                    address = chunks[3];
                    email = chunks[4];
                    try {output = new CMS.CustomerInfo(ID, firstName, lastName, address, email);
                            }
                    catch(Exception ex) {
                        System.out.println("fromCustom\n" + ex.toString());}
                }
            }
        }
        return(output);
    }
    
    public static CMS.CustomerInfo fromXML(String input) {
        CMS.CustomerInfo currentCustomer = null;
        boolean didFind;
        String ID = "";
        String firstName = "";
        String lastName = "";
        String address = "";
        String email = "";
        java.util.regex.Pattern regex = java.util.regex.Pattern.compile(
                                                                        "<CustomerInfo>\\s*" + 
                                                                            "<ID>(.*)</ID>\\s*" +
                                                                            "<FirstName>(.*)</FirstName>\\s*" +
                                                                            "<LastName>(.*)</LastName>\\s*" +
                                                                            "<Address>(.*)</Address>\\s*" +
                                                                            "<Email>(.*)</Email>\\s*" +
                                                                        "</CustomerInfo>"
                                                                        );
                java.util.regex.Matcher matcher = regex.matcher(input);
                didFind = matcher.find();                
                if(didFind == true) {
                    ID = matcher.group(1);
                    firstName = matcher.group(2);
                    lastName = matcher.group(3);
                    address = matcher.group(4);
                    email = matcher.group(5); 
                    try {
                        currentCustomer = new CustomerInfo(ID, firstName, lastName, address, email);
                    } catch(Exception ex) {
                        System.out.println("CustomerInfo.fromXML\n" + ex.toString());
                    } 
                } else {
                    System.out.println("CustomerInfo.fromXML");}
        return(currentCustomer);
    }
    
    public static CMS.CustomerInfo fromJSON(String input) {
        CMS.CustomerInfo currentCustomer = null;
        String ID = "";
        String firstName = "";
        String lastName = "";
        String address = "";
        String email = "";
        java.util.regex.Pattern regex = java.util.regex.Pattern.compile("\"ID\":\"(.*)\",\\s*"
                                                                           + "\"FirstName\":\"(.*)\",\\s*"
                                                                           + "\"LastName\":\"(.*)\",\\s*"
                                                                           + "\"Address\":\"(.*)\",\\s*"
                                                                           + "\"Email\":\"(.*)\"\\s*");
        java.util.regex.Matcher matcher = regex.matcher(input);
        if(matcher.find() == true) {   
            ID = matcher.group(1);
            firstName = matcher.group(2);
            lastName = matcher.group(3);
            address = matcher.group(4);
            email = matcher.group(5);
            try {
                currentCustomer = new CMS.CustomerInfo(ID, firstName, lastName, address, email);
            } catch (Exception ex) {
                System.out.println("fromJSON");
                System.out.println(ex.toString());}
        } else {
            System.out.println("fromJSON");}
        return(currentCustomer);
    }
    private CustomerInfo() {
        this.ID = "";
        this.firstName = "";
        this.lastName = "";
        this.address = "";
        this.email = "";
        this.status = CMS.CustomerInfo.CustomerInfoStatus.unknown;}
    public CustomerInfo(String ID, String email) throws Exception {
        this.ID = "";
        this.firstName = "";
        this.lastName = "";
        this.address = "";
        this.email = "";
        this.status = CMS.CustomerInfo.CustomerInfoStatus.unknown;
        if(validateID(ID) == false) {
            throw new Exception("CustomerInfo");
            // throw new IllegalArgumentException();
        } else if(validateEmail(email) == false) {
            this.status = CMS.CustomerInfo.CustomerInfoStatus.inactive;
            this.ID = ID;
        } else {
            this.status = CMS.CustomerInfo.CustomerInfoStatus.active;
            this.ID = ID;
            this.email = email;}
    }
    public CustomerInfo(String ID, String firstName, String lastName, String address, String email) throws Exception {
        this.ID = "";
        this.firstName = "";
        this.lastName = "";
        this.address = "";
        this.email = "";
        this.status = CMS.CustomerInfo.CustomerInfoStatus.unknown;
        if(validateID(ID) == false) {
            System.out.println(" enter a valid ID!");
            throw new Exception("Invalid ID!");
        } else {
            if(validateEmail(email) == false) {
                System.out.println("Email not valid!");
                this.email = "";
            } else {
                this.ID = ID;
                this.firstName = firstName;
                this.lastName = lastName;
                this.address = address;
                this.email = email;}
        }
    }
    private boolean validateFields() {
        // Validates all fields, therefore does not need an argument passed to it
        boolean areFieldsValid = false;
        if(validateEmail(this.email) == true ||
           validateID(this.ID) == true) {
            areFieldsValid = true;}
        return(areFieldsValid);
    }
    private boolean validateEmail(String email) {  
        boolean isValidEmail = false;
        java.util.regex.Pattern regex = java.util.regex.Pattern.compile(".*@.*\\..*");
        java.util.regex.Matcher matcher = regex.matcher(email);
        if(matcher.find() == true) {
            isValidEmail = true;
        } else {
            System.out.println("CustomerInfo"); }
        return(isValidEmail);
    }
    
    private boolean validateID(String ID) {
        boolean isIDValid = false;
         if((ID != null) && 
            (ID.length() != 0) &&
             CMS.CustomerInfoManager.searchForCustomer("ID", ID).length == 0) {
             isIDValid = true;}
         return(isIDValid);}
}