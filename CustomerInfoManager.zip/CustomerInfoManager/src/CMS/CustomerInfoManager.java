
//CustomerInfoManger
//Nathan Collins 
//NATCOL


package CMS;
import java.util.Arrays;
public class CustomerInfoManager {
    private static settingsInfo currentSettings;
    private static java.util.ArrayList<CMS.CustomerInfo> CustomerList;
    public static void main(String[] args) {
        // Initialize
        currentSettings = new settingsInfo();
        currentSettings = settingsInfo.getSettingsInfo();
        CustomerList = new java.util.ArrayList<CMS.CustomerInfo>();
        importAll(currentSettings.getRepository(), currentSettings.getFormat());
        java.util.Scanner scanner = new java.util.Scanner(System.in);         
//call help
        if(args.length == 0 || 
           args[0].equalsIgnoreCase("/h") == true || 
           args[0].equalsIgnoreCase("/help") == true) {
            help();
// add 
        } else if(args.length == 4 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/add") == true) {
                  String ID = args[2];
                  String email = args[3];
            try {CMS.CustomerInfo addedCustomer = new CMS.CustomerInfo(ID, email);
                addCustomer(addedCustomer);
                ArrayListCount(addedCustomer, "added");
                exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
            } catch(Exception ex) {System.out.println("Error: Exception thrown in main\n" + ex.toString());} 
        } else if(args.length == 7 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/add") == true) {
                  String ID = args[2];
                  String firstName = args[3];
                  String lastName = args[4];
                  String address = args[5];
                  String email = args[6];
            try {CMS.CustomerInfo addedCustomer = new CMS.CustomerInfo(ID, firstName, lastName, address, email);
                addCustomer(addedCustomer);
                ArrayListCount(addedCustomer, "added");
                exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
            } catch(Exception ex) {
                System.out.println("In main() -- Error: Exception thrown\n" + ex.toString());}
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/Customer") == true && 
                  args[1].equalsIgnoreCase("/add") == true) {
                  String ID = "";
                  String firstName = "";
                  String lastName = "";
                  String address = "";
                  String email = "";
            System.out.println("Please enter an ID:");
            ID = scanner.nextLine();
            System.out.println("Please enter first name:");
            firstName = scanner.nextLine();     
            System.out.println("Please enter last name:");
            lastName = scanner.nextLine();
            System.out.println("Please enter address:");
            address = scanner.nextLine();
            System.out.println("Please enter email address:");
            email = scanner.nextLine();
            try {
                CMS.CustomerInfo addedCustomer = new CMS.CustomerInfo(ID, firstName, lastName, address, email);
                addCustomer(addedCustomer);
                ArrayListCount(addedCustomer, "added");
                exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
            } catch(Exception ex) {System.out.println("main()\n" + ex.toString());}
//search
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/search")) {
            String chunks[];
            int indaces[];
            String value = args[2];
            chunks = value.split("=");
            value = chunks[1];
            indaces = searchForCustomer("ID", value);
            for(int index = 0; index < indaces.length; index++) {
                CMS.CustomerInfo currentCustomer = CustomerList.get(indaces[index]);
                System.out.println(currentCustomer.toCustom());}
        } else if(args.length == 4 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/search")) {
            String chunks[];
            int indaces[];
            String field = args[2];
            String value = args[3];
            chunks = field.split("=");
            field = chunks[1];
            chunks = value.split("=");
            value = chunks[1];
            indaces = searchForCustomer(field, value);
            for(int index = 0; index < indaces.length; index++) {
                CMS.CustomerInfo currentCustomer = CustomerList.get(indaces[index]);
                System.out.println(currentCustomer.toCustom());
            }
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/search") == true) {
            String field = "";
            String value = "";
            int indaces[];            
            System.out.println("field to search:");
            field = scanner.nextLine(); 
            System.out.println("enter the value to search:");
            value = scanner.nextLine(); 
            indaces = searchForCustomer(field, value);           
            for(int index = 0; index < indaces.length; index++) {
                CMS.CustomerInfo currentCustomer = CustomerList.get(indaces[index]);
                System.out.println(currentCustomer.toCustom());
            }
//update            
        } else if(args.length == 5 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/update") == true) {
            String chunks[];
            int indaces[];
            String ID = args[2];
            String field = args[3];
            String value = args[4];
            chunks = ID.split("=");
            ID = chunks[1]; 
            chunks = field.split("=");
            field = chunks[1]; 
            chunks = value.split("=");
            value = chunks[1];            
            indaces = searchForCustomer("ID", ID);
            updateCustomerInfo(indaces, field, value);
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat()); 
        } else if(args.length == 2 && 
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/update") == true) {
            int indaces[];
            String ID = "";
            String field = "";
            String value = "";            
            System.out.println("ID of the Customer to update:");
            ID = scanner.nextLine();           
            System.out.println("field to update:");
            field = scanner.nextLine();  
            System.out.println("enter the value to set:");
            value = scanner.nextLine();            
            indaces = searchForCustomer("ID", ID); 
            updateCustomerInfo(indaces, field, value);    
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
//delete
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/delete") == true) {
            String chunks[];
            int indaces[];
            String ID = args[2];  
            chunks = ID.split("=");
            ID = chunks[1];  
            indaces = searchForCustomer("ID", ID);
            deleteCustomer(indaces);      
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());    
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/delete") == true) {            
            int indaces[];
            String ID = "";       
            System.out.println("Please enter the ID of the Customer to delete:");
            ID = scanner.nextLine();            
            indaces = searchForCustomer("ID", ID);          
            deleteCustomer(indaces);      
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
//archive
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/archive") == true) {
            String chunks[];
            int indaces[];
            String ID = args[2];
            chunks = ID.split("=");
            ID = chunks[1];   
            indaces = searchForCustomer("ID", ID);  
            archiveCustomer(CustomerList.get(indaces[0]));       
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/Customer") == true &&
                  args[1].equalsIgnoreCase("/archive") == true) {            
            int indaces[];
            String ID = "";
            System.out.println("Please enter the ID of the Customer"); 
            indaces = searchForCustomer("ID", ID);
            archiveCustomer(CustomerList.get(indaces[0]));
//export

        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/export") == true &&
                  args[1].equalsIgnoreCase("/format") == true) {
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/export") == true &&
                  args[1].equalsIgnoreCase("/format") == true) {                     
//edit setting
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/setting") == true &&
                  args[1].equalsIgnoreCase("/repository") == true) {   
            java.io.File currentFile = new java.io.File(currentSettings.getRepository() + "." + currentSettings.getFormat());
            importAll(currentSettings.getRepository(), currentSettings.getFormat());
            currentFile.delete();      
            currentSettings.setRepository(args[2]);
            currentSettings.setSettingsInfo();
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());            
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/setting") == true &&
                  args[1].equalsIgnoreCase("/repository") == true) {    
            String repository = "";
            java.io.File currentFile = new java.io.File(currentSettings.getRepository() + "." + currentSettings.getFormat());
            importAll(currentSettings.getRepository(), currentSettings.getFormat());
            currentFile.delete();  
            System.out.println("Please enter the repository filename (do not include the file extension):");
            repository = scanner.nextLine();  
            currentSettings.setRepository(repository);
            currentSettings.setSettingsInfo();
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());
        } else if(args.length == 3 &&
                  args[0].equalsIgnoreCase("/setting") == true &&
                  args[1].equalsIgnoreCase("/format") == true) { 
            java.io.File currentFile = new java.io.File(currentSettings.getRepository() + "." + currentSettings.getFormat());
            importAll(currentSettings.getRepository(), currentSettings.getFormat());
            currentFile.delete();  
            currentSettings.setFormat(args[2]);
            currentSettings.setSettingsInfo();
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());  
        } else if(args.length == 2 &&
                  args[0].equalsIgnoreCase("/setting") == true &&
                  args[1].equalsIgnoreCase("/format") == true) {
            String format = "";
            java.io.File currentFile = new java.io.File(currentSettings.getRepository() + "." + currentSettings.getFormat());
            importAll(currentSettings.getRepository(), currentSettings.getFormat());
            currentFile.delete();
            System.out.println("format of repository csv custom json xml):");
            format = scanner.nextLine();
            currentSettings.setFormat(format);
            currentSettings.setSettingsInfo();
            exportAll(CustomerList, currentSettings.getRepository(), currentSettings.getFormat());} 
    }
    
    public static boolean importAll(String repository, String format) {
        java.io.File importFile;
        java.io.FileReader importFileReader;
        java.io.BufferedReader importBufferedReader;
        CMS.CustomerInfo currentCustomerInfo;
        String line;
        boolean results = false;
        repository = repository + "." + format;
        importFile = new java.io.File(repository); 
        if(importFile.exists() == true) {
            try {importFileReader = new java.io.FileReader(importFile);
                importBufferedReader = new java.io.BufferedReader(importFileReader);
                if(format.equalsIgnoreCase("custom")) {   
                    while((line = importBufferedReader.readLine()) != null) {
                        // For loop to iterate through all lines needed for the
                        // obect in custom format
                        for(int index = 0; index < 4; index++) {
                            line += importBufferedReader.readLine();}  
                        currentCustomerInfo = CustomerInfo.fromCustom(line);                       
                        addCustomer(currentCustomerInfo); }
                    results = true;    
                } else if(format.equalsIgnoreCase("csv")) {  
                    while((line = importBufferedReader.readLine()) != null) {
                        currentCustomerInfo = CustomerInfo.fromCSV(line);    
                        addCustomer(currentCustomerInfo); }
                    results = true;    
                } else if(format.equalsIgnoreCase("xml")) {   
                    while((line = importBufferedReader.readLine()) != null) {
                        // For loop to iterate through all lines needed for the
                        // object in XML format
                        for(int index = 0; index < 6; index++) {
                            line += importBufferedReader.readLine(); } 
                        currentCustomerInfo = CustomerInfo.fromXML(line);
                        addCustomer(currentCustomerInfo); }
                    results = true;  
                } else if(format.equalsIgnoreCase("json")) {                     
                    while((line = importBufferedReader.readLine()) != null) {
                        // For loop to iterate through all lines needed for the
                        // object in JSON format
                        for(int index = 0; index < 6; index++) {
                            line += importBufferedReader.readLine(); } 
                        currentCustomerInfo = CustomerInfo.fromJSON(line);
                        addCustomer(currentCustomerInfo); } 
                    results = true;        
                } else {
                    System.out.println("importAll");
                }
            } catch (Exception ex) {
                System.out.println("importAll");
                System.out.println(ex.toString());}
        }
        return (results);
    }
    
    public static boolean exportAll(java.util.ArrayList<CMS.CustomerInfo> CustomerList, String repository, String format) {
        java.io.File exportFile;
        java.io.FileWriter exportFileWriter;
        boolean results = true;        
        repository = repository + "." + format;       
        try {
            exportFile = new java.io.File(repository);
            exportFileWriter = new java.io.FileWriter(exportFile);           
            for(int index = 0; index < CustomerList.size(); index++) {
                if(format.equalsIgnoreCase("custom") == true) {
                    exportFileWriter.write(CustomerList.get(index).toCustom());
                } else if(format.equalsIgnoreCase("csv") == true) {
                    exportFileWriter.write(CustomerList.get(index).toCSV());
                } else if(format.equalsIgnoreCase("xml") == true) {
                    exportFileWriter.write(CustomerList.get(index).toXML());
                } else if(format.equalsIgnoreCase("json") == true) {
                    exportFileWriter.write(CustomerList.get(index).toJSON());
                } else {
                    System.out.println("exportAll");
                    results = false; }
            }      
            exportFileWriter.close();           
        } catch(Exception ex) {
            System.out.println("exportAll");
            System.out.println(ex.toString());
            results = false; }     
        return(results);
    }
    
    public static int[] searchForCustomer(String field, String value) {
        int index;
        int foundIndexes[] = new int[0];          
        if(field.equalsIgnoreCase("ID") == true) {
                for(index = 0; index < CustomerList.size(); index++) {
                    CMS.CustomerInfo currentCustomer = CustomerList.get(index);
                    String currentID = currentCustomer.getID();
                    if(currentID.equalsIgnoreCase(value)) {
                        foundIndexes = ChangeList(foundIndexes, index);}
                }
            } else if(field.equalsIgnoreCase("FirstName") == true) {
                for(index = 0; index < CustomerList.size(); index++) {
                    CMS.CustomerInfo currentCustomer = CustomerList.get(index);
                    String currentID = currentCustomer.getFirstName();
                    if(currentID.equalsIgnoreCase(value)) {
                        foundIndexes = ChangeList(foundIndexes, index);}
                }
            } else if(field.equalsIgnoreCase("LastName") == true) {
                for(index = 0; index < CustomerList.size(); index++) {
                    CMS.CustomerInfo currentCustomer = CustomerList.get(index);
                    String currentID = currentCustomer.getLastName();
                    if(currentID.equalsIgnoreCase(value)) {
                        foundIndexes = ChangeList(foundIndexes, index);}
                }
            } else if(field.equalsIgnoreCase("Address") == true) {
                for(index = 0; index < CustomerList.size(); index++) {
                    CMS.CustomerInfo currentCustomer = CustomerList.get(index);
                    String currentID = currentCustomer.getAddress();
                    if(currentID.equalsIgnoreCase(value)) {
                        foundIndexes = ChangeList(foundIndexes, index); }
                }
            } else if(field.equalsIgnoreCase("Email") == true) {
                for(index = 0; index < CustomerList.size(); index++) {
                    CMS.CustomerInfo currentCustomer = CustomerList.get(index);
                    String currentID = currentCustomer.getEmail();
                    if(currentID.equalsIgnoreCase(value)) {
                        foundIndexes = ChangeList(foundIndexes, index);}
                }
            } else {
                System.out.println("searchForCustomer");}
        return(foundIndexes);
    }
    
    public static boolean updateCustomerInfo(int[] foundIndexes, String field, String value) {
        boolean results = true;    
        if(foundIndexes.length > 1) {
            System.out.println("updateCustomerInfo");
            results = false;
        } else if(foundIndexes.length < 1) {
            System.out.println("updateCustomerInfo");
            results = true;
        } else {ArrayListCount(CustomerList.get(foundIndexes[0]), "updated");     
            if(field.equalsIgnoreCase("ID") == true) {
                System.out.println("In updateCustomerInfo() -- Warning: IDs cannot be updated!");
            } else if(field.equalsIgnoreCase("FirstName") == true) {
                CustomerList.get(foundIndexes[0]).setFirstName(value);
            } else if(field.equalsIgnoreCase("LastName") == true) {
                CustomerList.get(foundIndexes[0]).setLastName(value);
            } else if(field.equalsIgnoreCase("Address") == true) {
                CustomerList.get(foundIndexes[0]).setAddress(value);
            } else if(field.equalsIgnoreCase("Email") == true) {
                CustomerList.get(foundIndexes[0]).setEmail(value);
            } else {System.out.println("updateCustomerInfo");
                results = false;
            }
        }
        return(results);
    }
    
    public static boolean addCustomer(CMS.CustomerInfo potentialCustomer) {  
        CustomerList.add(potentialCustomer);     
        return(true);
    }
    
    public static boolean deleteCustomer(int[] indaces) {
        boolean results = false;
        System.out.println("Removed Customer(s):\n");
        for(int index = 0; index < indaces.length; index++) {
            ArrayListCount(CustomerList.get(indaces[index]), "deleted");
            System.out.println(CustomerList.get(indaces[index]).toCustom() + "\n\n");
            CustomerList.remove(indaces[index]);}     
        return(true);
    }
    
    public static boolean archiveCustomer(CMS.CustomerInfo archivedCustomer) {
        boolean results = false;
        java.io.File archiveFile;
        java.io.FileWriter archiveFileWriter;
        String filename = "archive.xml"; 
        try { archiveFile = new java.io.File(filename);
            archiveFileWriter = new java.io.FileWriter(archiveFile);
            
            archiveFileWriter.write(archivedCustomer.toXML());
            archiveFileWriter.close();
        } catch (Exception ex) {
            System.out.println("archiveCustomer\n" + ex.toString());}
        return(results);
    }
    
    public static int[] ChangeList(int[] OriginList, int addingInt) {
        int NewList[] = Arrays.copyOf(OriginList, OriginList.length + 1);
        NewList[NewList.length - 1] = addingInt; 
        return (NewList);
    }
    
    public static boolean ArrayListCount(CMS.CustomerInfo changedCustomer, String action) {
        boolean results = true;
        java.io.File logFile;
        java.io.FileWriter logFileWriter;
        try {logFile = new java.io.File("ChangeLog.txt");
            logFileWriter = new java.io.FileWriter(logFile, true); 
            if(action.equalsIgnoreCase("updated") == true) {
                logFileWriter.append("The following Customer:\n" + changedCustomer.toCustom() + "\n was " + action + ".\n\n\n\n");
            } else if(action.equalsIgnoreCase("added") == true) {
                logFileWriter.append("The following Customer:\n" + changedCustomer.toCustom() + "\n was " + action + ".\n\n\n\n");
            } else if(action.equalsIgnoreCase("deleted") == true) {
                logFileWriter.append("The following Customer:\n" + changedCustomer.toCustom() + "\n was " + action + ".\n\n\n\n");
            } else {
                System.out.println("ArrayListCount");
                results = false;}
            logFileWriter.close();
        } catch(Exception ex) {
            System.out.println(" ArrayListCount\n" + ex.toString());
            results = false;}
        return(results);
    }
//help
    public static void help() {
        System.out.println("*************************************************************************************************");
        System.out.println("/h                                                             Runs help function");
        System.out.println("/help                                                          Runs help function");
        System.out.println("/setting /repository filename                                Updates repository filename");
        System.out.println("/setting /format custom  csv  xml  json                   Updates repository format");
        System.out.println("/add ID Email                                              Adds Customer to repository");
        System.out.println("/add ID Firstname Lastname Address Email             Adds Customer to repository");
        System.out.println("/Customer /search ID=ID                                      Searches for Customer via ID");
        System.out.println("/Customer /search field  value                  Searches for Customer via specified field");
        System.out.println("/Customer /update ID field value          Updates specified field on a Customer");
        System.out.println("/Customer /delete ID                                     Deletes Customer with specified ID");
        System.out.println("/Customer /archive ID                                     Adds Customer to archive list");
        System.out.println("/export /format custom  csv  xml  json                    Exports Customer list in format"); 
        System.out.println("*************************************************************************************************");}
}

class settingsInfo {
    public String repository;
    public String format;
    
    public settingsInfo() {
        repository = "";
        format = "";}
    
    public static CMS.settingsInfo getSettingsInfo() {
        java.io.File inputFile = new java.io.File("SettingInfo.xml");
        java.io.FileReader inputFileReader  = null;
        java.io.BufferedReader inputBufferedReader = null;
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String contents = "";
        String line = "";
        String repository;
        String format;
        settingsInfo newSettings = null;        
        if(inputFile.exists() == true) {
            try {
                inputFileReader = new java.io.FileReader(inputFile);
                inputBufferedReader = new java.io.BufferedReader(inputFileReader);
                while((line = inputBufferedReader.readLine()) != null) {
                    contents += line; }  
                inputBufferedReader.close();
                inputFileReader.close();              
                java.util.regex.Pattern regex = java.util.regex.Pattern.compile("<settingsInfo>\\s*" + "<repository>(\\w*)</repository>\\s*" + "<format>(\\w*)</format>");
                java.util.regex.Matcher matcher = regex.matcher(contents);
                if(matcher.find() == true) {
                    repository = matcher.group(1);
                    format = matcher.group(2);
                    newSettings = new settingsInfo();
                    newSettings.setFormat(format);
                    newSettings.setRepository(repository);    
                } else {
                    System.out.println("wrong format");}
            } catch(Exception ex) {
                System.out.println("getSettings\n" + ex.toString());}
        } else {
            System.out.println("This creates a settings file for this program.");
        
            System.out.println("Please enter file name");
            repository = scanner.nextLine();
            System.out.println("Please enter file format (csv, custom, json, or xml are supported filetypes)");
            format = scanner.nextLine();
            newSettings = new settingsInfo();
            newSettings.setFormat(format);
            newSettings.setRepository(repository);   
            newSettings.setSettingsInfo();}
        return(newSettings);
    }
    
    public boolean setSettingsInfo() {
        // Write contents of an XML file with the updated application settings
        boolean output = true;
        java.io.File settingsInfoFile = new java.io.File("SettingInfo.xml");
        java.io.FileWriter settingsInfoWriter = null;
        try {settingsInfoWriter = new java.io.FileWriter("SettingInfo.xml");     
            System.out.println(this.toXML());
            settingsInfoWriter.write(this.toXML());   
            settingsInfoWriter.close();
        } catch(Exception ex) {
            System.out.println("set setting " + ex.toString());
            output = false;}
        return(output);
    }

    public String getRepository() {
        return this.repository;}
    
    public void setRepository(String repository) {
        this.repository = repository;}

    public String getFormat() {
        return this.format;}

    public void setFormat(String format) {
        if((format.equalsIgnoreCase("custom") == true) || (format.equalsIgnoreCase("csv") == true) || 
           (format.equalsIgnoreCase("json") == true) || (format.equalsIgnoreCase("xml") == true)) {
            this.format = format;
        } else {
            System.out.println("couldn't change format");}
    }
    
    public String toXML() {
        String output = "";
        output += "<settingsInfo>\n";
        output += "    <repository>" + this.repository + "</repository>\n";
        output += "    <format>" + this.format + "</format>\n";
        output += "</settingsInfo>\n"; 
        return(output);
    }
}